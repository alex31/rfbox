Dear Customer!

Thank you for downloading the Teseus_V3.2.14 tool,
which contains several stability and functional enhancements versus elder versions.

What's new?
____________
The most important feature (from user viewpoint) is a self-check of the firmware stored on SIB boards
upon launch of the TESEUS tool.
Previous SIB firmware versions are automatically updated to the new firmware version,
delivered with this package.
This process is launched automatically and if accomplished successfully , then only once,
as the firmware is stored in non-volatile flash on SIB boards.

Important notice:
please do not unplug the USB cable connecting the SIB to PC (or laptop)
nor power down the equippment during the update process (which may take several seconds).
A forced power down or unplug of the USB-connection may render to useless the firmware stored in the 
SIB board.
Therefore please make sure before first time connecting a SIB board to a PC/laptop with the 
Teseus_V3.2.14 tool installed  that the battery charge state is sufficient (by laptops)
or an uninterruptible mains supply is provided by PCs.

For detailed installation  instructions please read the free downloadable associated material
(TDA5150_EvaluationKit_UserGuide_V1.0.pdf)


Installation
____________

Please save the 
Teseus_autoinstaller_3_2_14.exe
file to a convenient location on your local drive and 
launch the self-extracting .exe file.
Further follow the instructions in the popup window.

Note: install process  may stall if the self-extracting file is extracted to a network drive,
use local drive(s) instead.
